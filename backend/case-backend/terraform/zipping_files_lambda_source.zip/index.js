const { S3Client, ListObjectsCommand, GetObjectCommand } = require("@aws-sdk/client-s3");
const { Upload } = require("@aws-sdk/lib-storage");
const { fromNodeProviderChain } = require("@aws-sdk/credential-provider-node");
const archiver = require("archiver");
const { PassThrough } = require("stream");

require("dotenv").config();

const fetchCredentials = async () => {
  try {
    const provider = fromNodeProviderChain();
    return await provider();
  } catch (error) {
    console.error("🚨 AWS Credentials Error:", error);
    throw new Error("AWS credentials could not be loaded.");
  }
};

const createS3Client = async () => {
  const credentials = await fetchCredentials();
  return new S3Client({ region: process.env.REGION, credentials });
};

exports.handler = async (event) => {
  const caseId = event.caseId;
  if (!caseId) {
    console.error("🚨 caseId is required.");
    return;
  }

  const s3Client = await createS3Client();
  const bucketName = process.env.DOCS_BUCKET_NAME;
  const zipBucketName = process.env.ZIP_BUCKET_NAME || bucketName;
  const folderName = `${caseId}/`;
  const zipFileName = `${caseId}_documents.zip`;
  const zipFileKey = `zipped/${zipFileName}`;

  try {
    console.log(`🔍 Listing files in bucket: ${bucketName}, folder: ${folderName}`);

    // List objects
    const listCommand = new ListObjectsCommand({ Bucket: bucketName, Prefix: folderName });
    const listResponse = await s3Client.send(listCommand);

    if (!listResponse.Contents || listResponse.Contents.length === 0) {
      console.log(`❌ No files found for caseId: ${caseId}, skipping zip.`);
      return;
    }

    console.log(`✅ Found ${listResponse.Contents.length} files, starting zip.`);

    const archive = archiver("zip", { zlib: { level: 9 } });
    const passThrough = new PassThrough();

    const upload = new Upload({
      client: s3Client,
      params: {
        Bucket: zipBucketName,
        Key: zipFileKey,
        Body: passThrough,
        ContentType: "application/zip",
      },
    });

    archive.pipe(passThrough);

    for (const item of listResponse.Contents) {
      const fileKey = item.Key;
      if (fileKey.endsWith("/")) continue;

      console.log(`📥 Fetching file: ${fileKey}`);
      const getCommand = new GetObjectCommand({ Bucket: bucketName, Key: fileKey });
      const response = await s3Client.send(getCommand);

      if (!response.Body) {
        console.warn(`⚠️ Skipping empty file: ${fileKey}`);
        continue;
      }

      archive.append(response.Body, { name: fileKey.replace(folderName, "") });
    }

    console.log(`🚀 Finalizing zip archive...`);
    await Promise.all([archive.finalize(), upload.done()]);
    console.log(`✅ Zip created successfully for caseId: ${caseId}`);

  } catch (error) {
    console.error(`🚨 Error creating zip for caseId: ${caseId}:`, error);
  }
};
